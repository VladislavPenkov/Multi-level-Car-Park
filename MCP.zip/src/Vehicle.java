public class Vehicle {

    protected enum VehicleType { STANDARD, HIGHER,
        LONGER, COACH, MOTORBIKE }

    String licensePlate;
    VehicleType type;
    String receiptNo;
    boolean disabledDriver;

    public Vehicle() {
        disabledDriver = false;
    }

    public boolean isDisabledDriver() {
        return disabledDriver;
    }

    public void setDisabledDriver(boolean disabledDriver) {
        this.disabledDriver = disabledDriver;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public VehicleType getType() {
        return type;
    }

    public void setType(VehicleType type) {
        this.type = type;
    }

    public String getReceiptNo() {
        return receiptNo;
    }

    public void setReceiptNo(String receiptNo) {
        this.receiptNo = receiptNo;
    }

}
