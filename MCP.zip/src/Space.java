public class Space {

    Vehicle occupant;
    String receiptID;

    public Space() {

    }

    public Vehicle getOccupant() {
        return occupant;
    }

    public void setOccupant(Vehicle vehicle) {
        occupant = vehicle;
    }

    public String getReceiptID() {
        return receiptID;
    }

    public void setReceiptID(String receiptID) {
        this.receiptID = receiptID;
    }

    public boolean isEmpty() {
        return (occupant == null);
    }

}
