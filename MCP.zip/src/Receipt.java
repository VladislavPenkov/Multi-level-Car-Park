public class Receipt {

    long arrivalTime;
    String spaceID;

    public Receipt() {
        this.arrivalTime = System.currentTimeMillis();
    }

    public long getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(long arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getSpaceID() {
        return spaceID;
    }

    public void setSpaceID(String spaceID) {
        this.spaceID = spaceID;
    }
}
