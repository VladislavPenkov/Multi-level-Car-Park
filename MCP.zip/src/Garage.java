import java.io.*;
import java.util.*;

/**
 * @Author vmp1
 */

public class Garage {
    private Scanner userInput;
    private Random randomNums;
    ArrayList<Space> spaces;
    protected HashMap<String, Receipt> receipts;
    private float rates[] = { 1, 1, 1, 1, 1};
    ArrayList<Attendant> attendants = new ArrayList<>();

    public Garage() {
        initialise();
    }

    private void initialise() {
        randomNums = new Random();
        receipts = new HashMap<>(100);
        userInput = new Scanner(System.in);
        //Initialise spaces
        spaces = new ArrayList<>();
        for(int i = 0; i < 100; i++) {
            spaces.add(i, new Space());
        }
        //Load rates
        File rateFile = new File("src\\rates.txt");
        try {
            FileReader reader = new FileReader(rateFile);
            BufferedReader bufferedReader = new BufferedReader(reader);
            try {
                int numberZones = Integer.parseInt(bufferedReader.readLine());
                for(int i = 0; i < numberZones; i++) {
                    rates[i] = Float.parseFloat(bufferedReader.readLine());
                }
            }catch (IOException ioe) { ioe.printStackTrace(); }
        } catch(FileNotFoundException fnfe) { fnfe.printStackTrace(); }
    }

    protected String addVehicle(Vehicle vehicle, float height, float length) {
        //Classify the vehicle
            if(height < 0 && length < 0) {
                vehicle.setType(Vehicle.VehicleType.MOTORBIKE);
            } else {
                    if(height < 3 && (length >= 5.1 && length < 6)) {
                        vehicle.setType(Vehicle.VehicleType.LONGER);
                } else
                    if((height > 2 && height < 3) && length < 5) {
                        vehicle.setType(Vehicle.VehicleType.HIGHER);
                } else
                    if(height < 2 && length < 5) {
                        vehicle.setType(Vehicle.VehicleType.STANDARD);
                } else
                    if(length < 15) {
                        vehicle.setType(Vehicle.VehicleType.COACH);
                }
            }
            if(vehicle.getType() == null) {
                System.out.println(" MESSED UP ON VEHICLE CLASSIFICATION");
            }
        //Return a unique receipt
        String receiptNo = String.valueOf(randomNums.nextInt());
            while(receipts.containsKey(receiptNo) || !(Integer.parseInt(receiptNo) > 0)) {
                receiptNo = String.valueOf(randomNums.nextInt());
            }
            Receipt tempReceipt = new Receipt();
            String tempSpaceID = findParkingSpace(vehicle);
            tempReceipt.setSpaceID(tempSpaceID);
            receipts.put(receiptNo, tempReceipt);
            spaces.get(Integer.parseInt(tempSpaceID)).setOccupant(vehicle);
            spaces.get(Integer.parseInt(tempSpaceID)).setReceiptID(receiptNo);
            return receiptNo;
    }

    protected void removeVehicle(String receiptNo) {
        Receipt tempReceipt = receipts.get(receiptNo);
        int tempSpaceID = Integer.parseInt(tempReceipt.getSpaceID());
        spaces.get(tempSpaceID).setOccupant(null);
        spaces.get(tempSpaceID).setReceiptID(null);
        receipts.remove(receiptNo);
    }

    protected String findParkingSpace(Vehicle vehicle) {
        Vehicle.VehicleType tempType = vehicle.getType();
        int freeSpace = -1;
        if(tempType == Vehicle.VehicleType.STANDARD || tempType == Vehicle.VehicleType.HIGHER) {
            if(spacesFree(1)) {
                freeSpace = getFirstSpace(1);
            } else if(tempType == Vehicle.VehicleType.STANDARD && spacesFree(4)) {
                freeSpace = getFirstSpace(4);
            }
        }
        if(tempType == Vehicle.VehicleType.LONGER && spacesFree(2)) {
            freeSpace = getFirstSpace(2);
        }
        if(tempType == Vehicle.VehicleType.COACH && spacesFree(3)) {
            freeSpace = getFirstSpace(3);
        }
        if(tempType == Vehicle.VehicleType.MOTORBIKE && spacesFree(5)) {
            freeSpace = getFirstSpace(5);
        }
        return String.valueOf(freeSpace);
    }

    private boolean spacesFree(int zone) {
        int minID =0, maxID = 0;
        switch(zone) {
            case 1:
                minID = 0;
                maxID = 19;
                break;
            case 2:
                minID = 20;
                maxID = 39;
                break;
            case 3:
                minID = 40;
                maxID = 59;
                break;
            case 4:
                minID = 60;
                maxID = 79;
                break;
            case 5:
                minID = 80;
                maxID = 99;
                break;
        }
        for(int i = minID; i < maxID; i++) {
            if(spaces.get(i).isEmpty()) return true;
        }
        return false;
    }

    protected boolean spaceFree(String spaceID) {
        if(spaces.get(Integer.parseInt(spaceID)).isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    private int getFirstSpace(int zone) {
        int minID = 0, maxID = 0;
        switch(zone) {
            case 1:
                minID = 0;
                maxID = 19;
                break;
            case 2:
                minID = 20;
                maxID = 39;
                break;
            case 3:
                minID = 40;
                maxID = 59;
                break;
            case 4:
                minID = 60;
                maxID = 79;
                break;
            case 5:
                minID = 80;
                maxID = 99;
                break;
        }
        for(int i = minID; i < maxID; i++) {
            if(spaces.get(i).isEmpty()) {
                return i;
            }
        }
        return -1;
    }

    private int getZone(int spaceID) {
        if(spaceID < 20) {
            return 1;
        } else
            if(spaceID < 40) {
                return 2;
            } else
                if(spaceID < 60) {
                    return 3;
                } else
                    if(spaceID < 80) {
                        return 4;
                    } else {
                        return 5;
                    }
    }

    protected float calculateFee(String receiptID) {
        Receipt receipt = receipts.get(receiptID);
        if(receipts.containsKey(receiptID)) {
            Vehicle.VehicleType type = spaces.get(Integer.parseInt(receipt.getSpaceID())).getOccupant().getType();

            long currentTime = System.currentTimeMillis();
            long totalTime = currentTime - receipt.getArrivalTime();
            float totalTimeHours = (totalTime / 3600000);
            int zone = getZone(Integer.parseInt(receipt.getSpaceID()));
            if(!(totalTimeHours % 1 == 0)) {
                totalTimeHours = Math.floorMod((long) totalTimeHours, 1) + 1;
            }
            if (totalTimeHours < 1) {
                totalTimeHours = 1;
            }
            float finalFee = totalTimeHours * rates[zone - 1];
            if(type != Vehicle.VehicleType.COACH && spaces.get(Integer.parseInt(receipt.getSpaceID())).getOccupant().isDisabledDriver()) {
                finalFee = finalFee/2;
                System.out.println("For capitalism, it is never sunday. :)");
            }
            return finalFee;
        }
        return -1.1F;
    }

    protected void addAttendant(String name){
        Attendant tempAttendant = new Attendant();
        tempAttendant.setName(name);
        attendants.add(tempAttendant);
    }

    protected Attendant getRandomAttendant() {
        Attendant currentAttendant = new Attendant();
        currentAttendant.setFree(false);
        while(!currentAttendant.isFree) {
            currentAttendant = attendants.get(randomNums.nextInt(attendants.size()));
        }
        return currentAttendant;
    }

    protected boolean hasAttendantsAvailable() {
        for(Attendant a: attendants) {
            if(a.isFree()) return true;
        }
        return false;
    }

    protected Attendant getAttendant(String receiptNo) {
        for(Attendant a: attendants) {
            if(a.getReceiptNo().equals(receiptNo)) return a;
        }
        return null;
    }

    protected String listAttendants(){
        StringBuilder sb = new StringBuilder();
        for(Attendant a: attendants) {
            sb.append(a.getName());
            sb.append(" - ");
            if(a.isFree()) sb.append("FREE"); else sb.append("BUSY");
            sb.append("\n");
        }
        return sb.toString();
    }

    protected void removeAttendant(String name) {
        for(Attendant a: attendants) {
            if(a.getName().equals(name)) {
                attendants.remove(a);
                break;
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("State of spaces: \n");
        sb.append("\nZONE: 1\n");
        for(int i = 0; i < spaces.size(); i++) {
            sb.append("Space: ");
            sb.append(i);
            if(spaces.get(i).isEmpty()) {
                sb.append(" (EMPTY)");
            } else {
                sb.append(" (FULL!)");
            }
            if((i+1) >= spaces.size()) break;
            if(((i+1) % 20 == 0) && i != 0) {
                if(!(i == 4)) sb.append("\nZONE: " + ((i/20)+2));
            }
            if(((i+1) % 4 == 0) && (i % 10 != 0)) {
                sb.append("\n");
            } else {
                if(!((i+1)%20==0)) sb.append("   ");
            }
        }
        return sb.toString();
    }

}
