import java.util.InputMismatchException;
import java.util.Scanner;

public class Application {

    private Scanner userInput;
    private Garage garage;

    private void runMenu() {
        userInput.useDelimiter("\n");
        int currentSelection = -1;
        String receiptNo;
        while(currentSelection != 7) {
            try {
                System.out.print("Select an option by entering a number: \n" +
                        "1: Register vehicle\n" +
                        "2: Enter receipt and pay\n" +
                        "3: Display state of car park\n" +
                        "4: Attendant Options\n" +
                        "5: Seek Assistance\n" +
                        "6: Request vehicle pickup from attendant\n" +
                        "7: Quit\n");
                System.out.print("\nSelection: ");
                currentSelection = userInput.nextInt();
                switch (currentSelection) {
                    case 1:
                        System.out.println("To secure a space, you must first enter some information.");
                        System.out.println("Are you a disabled person? enter 'y' for yes or 'n' for no");
                        boolean isDisabled;
                        String disabledResponse = userInput.next();
                        if (disabledResponse.equals("n")) {
                            isDisabled = false;
                        } else {
                            isDisabled = true;
                        }
                        String licensePlateNumber;
                        System.out.println("Please enter your License Plate number: ");
                        licensePlateNumber = userInput.next();
                        Vehicle tempVehicle = new Vehicle();
                        tempVehicle.setDisabledDriver(isDisabled);
                        tempVehicle.setLicensePlate(licensePlateNumber);
                        System.out.println("Enter '1' if you have a motorbike, else enter '2'.");
                        if (userInput.nextInt() == 1) {
                            receiptNo = garage.addVehicle(tempVehicle, -1, -1);
                        } else {
                            System.out.println("Please enter your vehicle's height: ");
                            float height = userInput.nextFloat();
                            System.out.println("Please enter your vehicle's length: ");
                            float length = userInput.nextFloat();
                            receiptNo = garage.addVehicle(tempVehicle, height, length);
                        }
                        System.out.println("Your receipt number is: " + receiptNo);
                        System.out.println("You can now park at space " + garage.receipts.get(receiptNo).getSpaceID());
                        break;
                    case 2:
                        System.out.println("Please enter your receipt number: ");
                        receiptNo = userInput.next();
                        ExitToken customerToken = handleFees(receiptNo);
                        break;
                    case 3:
                        System.out.println(garage.toString() + "\n");
                        break;
                    case 4:
                        //Call an attendant to do your dirty work - ONLY WORKS IF NOT BIKE OR COACH
                        System.out.println("Select an option by entering the following number: ");
                        System.out.println("1: Valet Parking");
                        System.out.println("2: ADMIN - Add an attendant");
                        System.out.println("3: ADMIN - View all attendants");
                        System.out.println("4: ADMIN - Remove an attendant");
                        System.out.println("5: Back to Menu");
                        int subSelection = userInput.nextInt();
                        switch (subSelection) {
                            case 1:
                                System.out.println("Select your vehicle type by entering the following number: ");
                                System.out.println("1: Motorbike");
                                System.out.println("2: Coach");
                                System.out.println("3: Other");
                                int subSubSelection = userInput.nextInt();
                                if (subSubSelection == 3) {
                                    if (garage.hasAttendantsAvailable()) {
                                        Attendant currentAttendant = garage.getRandomAttendant();
                                        currentAttendant.setFree(false);
                                        System.out.println("WE IN ATTENDANT MODE NOW MOTHERFUCKERS B~)");
                                        System.out.println("Hello, " + currentAttendant.getName());
                                        //roaming
                                        int attendantChoice;
                                        while (true) {
                                            System.out.println("Enter the vehicle's spaceID (or -1 if there are no spaces)");
                                            attendantChoice = userInput.nextInt();
                                            if (attendantChoice == -1) break;
                                            if (garage.spaceFree(String.valueOf(attendantChoice))) {
                                                System.out.println("Please enter your License Plate number: ");
                                                licensePlateNumber = userInput.next();
                                                tempVehicle = new Vehicle();
                                                tempVehicle.setLicensePlate(licensePlateNumber);
                                                System.out.println("Enter '1' if you have a motorbike, else enter '2'.");
                                                if (userInput.nextInt() == 1) {
                                                    receiptNo = garage.addVehicle(tempVehicle, -1, -1);
                                                } else {
                                                    System.out.println("Please enter your vehicle's height: ");
                                                    float height = userInput.nextFloat();
                                                    System.out.println("Please enter your vehicle's length: ");
                                                    float length = userInput.nextFloat();
                                                    receiptNo = garage.addVehicle(tempVehicle, height, length);
                                                    currentAttendant.setReceiptNo(receiptNo);
                                                    currentAttendant.setFree(false);
                                                }
                                                System.out.println("Your receipt number is: " + receiptNo);
                                                System.out.println("Client's car is booked at space: " + garage.receipts.get(receiptNo).getSpaceID());
                                                break;
                                            } else {
                                                System.out.println("This space is currently occupied.");
                                                continue;
                                            }
                                        }
                                    } else {
                                        System.out.println("There are no attendants available.");
                                    }
                                } else {
                                    System.out.println("We are unable to valet your type of vehicle at this time." +
                                            "\nPlease try to register your vehicle manually.");
                                }
                                break;
                            case 2:
                                System.out.println("Please enter the attendant's name");
                                garage.addAttendant(userInput.next());
                                System.out.println("Attendant added");
                                break;
                            case 3:
                                if (garage.attendants.isEmpty()) {
                                    System.out.println("There are no attendants currently in service");
                                } else {
                                    System.out.println(garage.listAttendants() + "\n");
                                }
                                break;
                            case 4:
                                System.out.println("Enter the name of the attendant you want to remove: ");
                                garage.removeAttendant(userInput.next());
                                System.out.println("Attendant removed");
                                break;
                            case 5:
                                break;
                        }
                        break;
                    case 5:
                        System.out.println("Help is on the way");
                        break;
                    case 6:
                        System.out.println("Please enter your receipt number: ");
                        receiptNo = userInput.next();
                        ExitToken attendantToken = handleFees(receiptNo);
                        Attendant responsibleAdult = garage.getAttendant(receiptNo);
                        if (responsibleAdult == null) {
                            System.err.println("No attendant matching receipt");
                        } else {
                            if (attendantToken.isValid()) {
                                System.out.println("Your motorised transportation vessel is en-route to you now.");
                                responsibleAdult.setFree(true);
                                responsibleAdult.setReceiptNo(null);
                            } else {
                                System.out.println("Your token isn't valid. Try again.");
                                System.out.println("Your receipt number is still valid.");
                            }
                        }
                        break;
                    case 7:
                        break;
                    default:
                        System.err.println("Invalid choice!");
                }
            } catch(InputMismatchException ime) {
                System.err.println("I bet you think you're well smart typing that in wrong. FEEL MY WRATH");
                break;
            }
        }
    }

    private void initialise() {
        userInput = new Scanner(System.in);
        garage = new Garage();
    }

    private ExitToken handleFees(String receiptNo) {
        ExitToken newToken;
        float fee = garage.calculateFee(receiptNo);
        if(!(fee == -1.1F)) {
            System.out.println("Fee due: " + fee + " Units");
            System.out.println("Enter the amount you wish to pay: ");
            float intendedPay = userInput.nextFloat();
            if (intendedPay >= fee) {
                float change = intendedPay - fee;
                System.out.println("Change due: " + change);
                //gib tix pls
                garage.removeVehicle(receiptNo);
                newToken = new ExitToken(true);
            } else {
                float difference = fee - intendedPay;
                System.out.println("You need to pay " + difference + "Units more.");
                newToken = new ExitToken(false);
            }
            return newToken;
        } else {
            System.err.println("Invalid receiptID. Please try again.");
            return new ExitToken(false);
        }
    }

    public static void main(String[] args) {
        Application mcp = new Application();
        mcp.initialise();
        mcp.runMenu();

    }

    class ExitToken {

        private boolean isValid;

        public ExitToken(boolean valid) {
            this.isValid = valid;
        }

        protected void setValid(boolean valid) {
            this.isValid = valid;
        }

        protected boolean isValid() {
            return isValid;
        }

    }

}
