import java.util.ArrayList;

public class Attendant {
    String name;
    boolean isFree;
    String receiptNo;

    public Attendant() {
        this.name = "John Smith"; //an overused name
        this.isFree = true;
        this.receiptNo = null;
    }

    public String getReceiptNo() {
        return receiptNo;
    }

    public void setReceiptNo(String receiptNo) {
        this.receiptNo = receiptNo;
    }

    public boolean isFree() {
        return isFree;
    }

    public void setFree(boolean free) {
        isFree = free;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
